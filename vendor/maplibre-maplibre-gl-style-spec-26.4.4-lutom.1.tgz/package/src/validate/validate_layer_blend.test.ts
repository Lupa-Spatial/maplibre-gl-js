import {expect, test} from 'vitest';
import {validateStyle} from '../validate_style';
import v8 from '../reference/v8.json' with {type: 'json'};

test('fill and line accept exactly the renderer blend modes and default to normal', () => {
    const modes = ['normal', 'multiply', 'screen', 'overlay', 'color', 'luminosity', 'lighter'];
    for (const type of ['fill', 'line'] as const) {
        const property = `${type}-layer-blend`;
        const specification = type === 'fill' ? v8.paint_fill['fill-layer-blend'] : v8.paint_line['line-layer-blend'];
        expect(Object.keys(specification.values).sort()).toEqual([...modes].sort());
        expect(specification.default).toBe('normal');
        for (const mode of [...modes, 'erase']) {
            const errors = validateStyle({version: 8, sources: {source: {type: 'geojson', data: {type: 'FeatureCollection', features: []}}}, layers: [{id: type, type, source: 'source', paint: {[property]: mode}}]});
            expect(errors).toHaveLength(mode === 'erase' ? 1 : 0);
        }
    }
});
